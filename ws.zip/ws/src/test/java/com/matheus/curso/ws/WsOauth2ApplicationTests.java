package com.matheus.curso.ws;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WsOauth2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
