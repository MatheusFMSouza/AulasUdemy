package com.matheus.curso.ws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WsOauth2Application {

	public static void main(String[] args) {
		SpringApplication.run(WsOauth2Application.class, args);
	}

}
